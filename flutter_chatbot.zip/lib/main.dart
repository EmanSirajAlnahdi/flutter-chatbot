import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  runApp(const VoiceBotApp());
}

class VoiceBotApp extends StatelessWidget {
  const VoiceBotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Voice Chatbot',
      home: const VoiceHomePage(),
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8E7AB5)),
        useMaterial3: true,
        fontFamily: 'Arial',
      ),
    );
  }
}

class VoiceHomePage extends StatefulWidget {
  const VoiceHomePage({super.key});

  @override
  State<VoiceHomePage> createState() => _VoiceHomePageState();
}

class _VoiceHomePageState extends State<VoiceHomePage> {
  final stt.SpeechToText _stt = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _isListening = false;
  String _recognizedText = '';
  String _status = 'مرحباً! اضغط "تحدث الآن" وابدأ التحدث.';

  // Performance measurement
  final List<int> _measurementsMs = [];
  Stopwatch? _stopwatch;

  @override
  void initState() {
    super.initState();
    _initTts();
  }

  Future<void> _initTts() async {
    await _tts.setLanguage('ar-SA');
    await _tts.setSpeechRate(0.45);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
  }

  Future<bool> _ensurePermissions() async {
    final mic = await Permission.microphone.request();
    return mic.isGranted;
  }

  Future<void> _startListening() async {
    final ok = await _ensurePermissions();
    if (!ok) {
      setState(() => _status = 'المايك مرفوض. رجاءً فعّلي صلاحية الميكروفون.');
      return;
    }

    final available = await _stt.initialize(
      onStatus: (s) => debugPrint('[STT] $s'),
      onError: (e) => debugPrint('[STT][ERR] $e'),
    );
    if (!available) {
      setState(() => _status = 'التعرّف على الكلام غير متاح.');
      return;
    }

    setState(() {
      _recognizedText = '';
      _isListening = true;
      _status = 'جاري الاستماع...';
    });

    await _stt.listen(
      localeId: 'ar_SA',
      listenFor: const Duration(seconds: 8),
      pauseFor: const Duration(seconds: 2),
      onResult: (res) {
        setState(() => _recognizedText = res.recognizedWords);
      },
      cancelOnError: true,
    );

    // The STT will automatically stop after listenFor/pauseFor.
    // We also stop explicitly after a small delay to guarantee completion.
    Future.delayed(const Duration(milliseconds: 200), _stopListening);
  }

  Future<void> _stopListening() async {
    if (!_isListening) return;
    await _stt.stop();
    setState(() => _isListening = false);

    if (_recognizedText.trim().isEmpty) {
      setState(() => _status = 'لم أسمع شيئًا. حاول مرة أخرى.');
      return;
    }

    // Measure from after STT to TTS start
    _stopwatch = Stopwatch()..start();
    final reply = await getReply(_recognizedText);
    _stopwatch?.stop();
    final elapsed = _stopwatch?.elapsedMilliseconds ?? 0;
    _measurementsMs.add(elapsed);
    debugPrint('[Perf] response_ms=$elapsed');

    await _speak(reply);
    setState(() => _status = reply);
  }

  Future<void> _speak(String text) async {
    await _tts.stop();
    await _tts.speak(text);
  }

  // Replace with your model or API call
  Future<String> getReply(String userText) async {
    final t = userText.trim();
    // Very simple heuristic replies in Arabic for demo
    if (t.isEmpty) return 'لم أسمعك جيدًا، هل يمكنك الإعادة؟';
    if (t.contains('السلام') || t.contains('مرحبا') || t.contains('هلا')) {
      return 'وعليكم السلام، شلون أقدر أساعدك؟';
    }
    if (t.contains('اسمك') || t.contains('من انت')) {
      return 'أنا مساعد صوتي بسيط مكتوب بفلتر.';
    }
    if (t.contains('الوقت') || t.contains('الساعه')) {
      final now = DateTime.now();
      return 'الوقت الآن ${now.hour}:${now.minute.toString().padLeft(2, '0')}';
    }
    return 'تمام، سمعت: "$t". هذه نسخة تجريبية—اسألي سؤال آخر.';
  }

  String get averageMs {
    if (_measurementsMs.isEmpty) return '—';
    final sum = _measurementsMs.reduce((a, b) => a + b);
    final avg = sum / _measurementsMs.length;
    return avg.toStringAsFixed(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 8),
              const Text(
                'الأساليب الذكية',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 24),
              Text(
                _isListening ? 'جاري الاستماع...' : _status,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isListening ? null : _startListening,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                child: const Text('تحدث الآن', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 12),
              if (_recognizedText.isNotEmpty)
                Text('سمعت: $_recognizedText', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              Text('متوسط زمن الاستجابة (ms): $averageMs'),
            ],
          ),
        ),
      ),
    );
  }
}